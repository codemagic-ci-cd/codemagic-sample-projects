//
//  fastlyApp.swift
//  fastly
//
//  Created by Kevin Suhajda on 2021. 09. 09..
//

import SwiftUI

@main
struct fastlyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
